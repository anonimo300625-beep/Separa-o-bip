# API de sincronização (rascunho)

Esta pasta é o ponto de partida para a base central online. A API deve manter:
- produtos: código, rua, rack, coluna, linha;
- separações;
- registros de bipagem;
- operador/aparelho;
- status pendente/concluído;
- data/hora.

Antes de colocar em produção, adicione autenticação, HTTPS, controle de concorrência e backup.
