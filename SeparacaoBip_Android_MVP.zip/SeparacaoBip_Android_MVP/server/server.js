const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 8080;
const DB = path.join(__dirname, "data.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, JSON.stringify({products:[], records:[]}, null, 2));

function readDb(){ return JSON.parse(fs.readFileSync(DB, "utf8")); }
function writeDb(db){ fs.writeFileSync(DB, JSON.stringify(db, null, 2)); }
function body(req){ return new Promise((resolve,reject)=>{let d=""; req.on("data",c=>d+=c); req.on("end",()=>{try{resolve(d?JSON.parse(d):{})}catch(e){reject(e)}})})}
function send(res, code, obj){res.writeHead(code, {"Content-Type":"application/json","Access-Control-Allow-Origin":"*"}); res.end(JSON.stringify(obj));}

http.createServer(async (req,res)=>{
  if(req.method==="OPTIONS"){res.writeHead(204,{"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type"});return res.end();}
  const db=readDb();
  try{
    if(req.method==="GET" && req.url==="/health") return send(res,200,{ok:true});
    if(req.method==="GET" && req.url==="/products") return send(res,200,db.products);
    if(req.method==="GET" && req.url==="/records") return send(res,200,db.records);
    if(req.method==="POST" && req.url==="/products"){const p=await body(req); db.products.push(p); writeDb(db); return send(res,201,p);}
    if(req.method==="POST" && req.url==="/records"){const r=await body(req); db.records.push(r); writeDb(db); return send(res,201,r);}
    if(req.method==="PATCH" && req.url.startsWith("/records/")){
      const id=req.url.split("/").pop(), patch=await body(req), i=db.records.findIndex(x=>x.id===id);
      if(i<0)return send(res,404,{error:"not found"}); db.records[i]={...db.records[i],...patch}; writeDb(db); return send(res,200,db.records[i]);
    }
    return send(res,404,{error:"not found"});
  }catch(e){return send(res,400,{error:String(e)})}
}).listen(PORT,()=>console.log("API listening on "+PORT));
