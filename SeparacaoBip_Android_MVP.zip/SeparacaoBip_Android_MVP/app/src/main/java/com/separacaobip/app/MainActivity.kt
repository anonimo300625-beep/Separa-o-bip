package com.separacaobip.app

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class Product(val code:String, val street:String, val rack:String, val column:String, val line:String)
data class ScanRecord(
    val id:String, val code:String, val street:String, val rack:String, val column:String, val line:String,
    val operator:String, val timestamp:Long, var completed:Boolean
)

class MainActivity : android.app.Activity() {
    private lateinit var input: EditText
    private lateinit var operatorView: TextView
    private lateinit var status: TextView
    private lateinit var stats: LinearLayout
    private lateinit var recordsView: LinearLayout
    private val products = HashMap<String, Product>()
    private val records = ArrayList<ScanRecord>()
    private val prefs by lazy { getSharedPreferences("separacao", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        input = findViewById(R.id.scannerInput)
        operatorView = findViewById(R.id.operator)
        status = findViewById(R.id.status)
        stats = findViewById(R.id.stats)
        recordsView = findViewById(R.id.records)

        loadProducts()
        loadRecords()
        updateOperator()
        render()

        findViewById<Button>(R.id.changeOperator).setOnClickListener { askOperator() }
        findViewById<Button>(R.id.manualScan).setOnClickListener { processInput() }
        input.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                processInput(); true
            } else false
        }
        input.requestFocus()
    }

    private fun loadProducts() {
        val text = assets.open("products.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val p = Product(o.getString("code"), o.getString("street"), o.getString("rack"),
                o.getString("column"), o.getString("line"))
            products[p.code] = p
        }
    }

    private fun loadRecords() {
        val text = prefs.getString("records", "[]") ?: "[]"
        val arr = JSONArray(text)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            records.add(ScanRecord(o.getString("id"), o.getString("code"), o.getString("street"),
                o.getString("rack"), o.getString("column"), o.getString("line"),
                o.getString("operator"), o.getLong("timestamp"), o.getBoolean("completed")))
        }
    }

    private fun saveRecords() {
        val arr = JSONArray()
        records.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("code", it.code); put("street", it.street); put("rack", it.rack)
                put("column", it.column); put("line", it.line); put("operator", it.operator)
                put("timestamp", it.timestamp); put("completed", it.completed)
            })
        }
        prefs.edit().putString("records", arr.toString()).apply()
    }

    private fun operator(): String = prefs.getString("operator", "") ?: ""

    private fun updateOperator() {
        val op = operator()
        operatorView.text = if (op.isBlank()) "Operador: não identificado" else "Operador: $op"
    }

    private fun askOperator() {
        val e = EditText(this).apply { setText(operator()); hint = "Nome do operador/aparelho" }
        AlertDialog.Builder(this).setTitle("Identificar aparelho")
            .setMessage("Esse nome será associado aos próximos bips.")
            .setView(e)
            .setPositiveButton("Salvar") { _, _ ->
                val name = e.text.toString().trim()
                if (name.isNotBlank()) {
                    prefs.edit().putString("operator", name).apply()
                    updateOperator()
                    input.requestFocus()
                }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun processInput() {
        val raw = input.text.toString().trim()
        input.setText("")
        if (raw.length < 6 || !raw.all { it.isDigit() }) {
            status.text = "⚠️ Código inválido. O leitor precisa enviar pelo menos 6 dígitos."
            input.requestFocus(); return
        }
        val code = raw.substring(raw.length - 6, raw.length - 1)
        val product = products[code]
        if (product == null) {
            status.text = "⚠️ Código $code não encontrado na base."
            input.requestFocus(); return
        }

        val pending = records.lastOrNull { it.code == code && !it.completed }
        if (pending != null) {
            AlertDialog.Builder(this)
                .setTitle("Código já bipado")
                .setMessage("O código $code ainda está pendente${if (pending.operator.isNotBlank()) " (bipado por ${pending.operator})" else ""}.\n\nAdicionar mesmo assim?")
                .setNegativeButton("Cancelar") { _, _ -> input.requestFocus() }
                .setPositiveButton("Adicionar mesmo assim") { _, _ -> addRecord(product) }
                .show()
        } else addRecord(product)
    }

    private fun addRecord(p: Product) {
        val op = operator()
        if (op.isBlank()) {
            askOperator()
            status.text = "Informe o nome do operador antes de registrar."
            input.requestFocus(); return
        }
        records.add(0, ScanRecord(UUID.randomUUID().toString(), p.code, p.street, p.rack, p.column, p.line,
            op, System.currentTimeMillis(), false))
        saveRecords()
        status.text = "✅ ${p.code} adicionado — ${p.street} / Rack ${p.rack} / Coluna ${p.column} / Linha ${p.line}"
        render()
        input.requestFocus()
    }

    private fun render() {
        stats.removeAllViews()
        val pending = records.count { !it.completed }
        val done = records.count { it.completed }
        addStat("PENDENTES\n$pending")
        addStat("CONCLUÍDOS\n$done")
        addStat("TOTAL\n${records.size}")

        recordsView.removeAllViews()
        val sdf = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR"))
        records.forEach { r ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 12, 12, 12)
                alpha = if (r.completed) 0.5f else 1f
            }
            val code = TextView(this).apply {
                text = if (r.completed) "✓ ${r.code}" else r.code
                textSize = 22f
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            val address = TextView(this).apply {
                text = "${r.street} — Rack ${r.rack} — Coluna ${r.column} — Linha ${r.line}"
                textSize = 17f
            }
            val meta = TextView(this).apply {
                text = "${r.operator} • ${sdf.format(Date(r.timestamp))} • ${if (r.completed) "Concluído" else "Pendente"}"
                textSize = 14f
            }
            val action = Button(this).apply {
                text = if (r.completed) "↩ Desfazer conclusão" else "✓ Concluir"
                setOnClickListener {
                    r.completed = !r.completed
                    saveRecords(); render(); input.requestFocus()
                }
            }
            box.addView(code); box.addView(address); box.addView(meta); box.addView(action)
            recordsView.addView(box)
            val divider = Space(this).apply { minimumHeight = 12 }
            recordsView.addView(divider)
        }
    }

    private fun addStat(text:String) {
        val t = TextView(this).apply {
            this.text = text
            textSize = 14f
            setPadding(8, 8, 8, 8)
        }
        stats.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
    }
}
