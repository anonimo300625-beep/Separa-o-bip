# Separação Bip — MVP Android

Projeto Android criado a partir da planilha `LinhaSeparacao_ATUAL.xlsx`.

## Regras implementadas no MVP

- Leitor C3Tech LB-W300BK tratado como entrada de teclado.
- Para cada código de barras, pega os **5 dígitos imediatamente anteriores ao último**.
  Exemplo: `7891033483037` → `48303`.
- Procura o código na base importada da planilha.
- Endereço exibido sempre como: **Rua → Rack → Coluna → Linha**.
- Códigos não encontrados geram aviso.
- Cada aparelho possui um nome de operador salvo localmente.
- Se um código já estiver **pendente**, o app pergunta se deseja adicionar mesmo assim.
- Se o registro anterior estiver **concluído**, um novo bip entra normalmente sem aviso.
- Concluir não apaga o registro; ele fica marcado como concluído.
- É possível desfazer a conclusão.
- Há contadores de pendentes, concluídos e total.

## Dados importados

A planilha possui 4146 linhas de dados; foram carregados 3060 códigos preenchidos, com 3060 códigos únicos.

## Internet / vários aparelhos

A estrutura do projeto inclui uma pasta `server/` com uma API simples para a futura sincronização central.
A versão gerada aqui já funciona com a base local da planilha, mas para vários aparelhos compartilharem alterações em tempo real será necessário hospedar essa API e configurar a URL no aplicativo. Isso é intencional: não inventei uma conta/servidor ou credenciais que você ainda não forneceu.

## Abrir no Android Studio

1. Abra a pasta do projeto no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Rode em um celular Android ou emulador.
4. Conecte o C3Tech por Bluetooth/USB conforme o modo de uso dele; se o leitor enviar os números como teclado, basta manter o campo de bipagem selecionado.

